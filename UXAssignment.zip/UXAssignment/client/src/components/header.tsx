import { Users, Bell } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();
  return (
    <header className="bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Users className="text-primary-foreground" size={16} />
              </div>
              <h1 className="text-xl font-semibold text-foreground">RecruitCRM</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <Link href="/dashboard" className={`transition-colors ${
                location === "/dashboard" 
                  ? "text-primary font-medium" 
                  : "text-muted-foreground hover:text-foreground"
              }`}>
                Dashboard
              </Link>
              <Link href="/" className={`transition-colors ${
                location === "/" || location.startsWith("/company")
                  ? "text-primary font-medium" 
                  : "text-muted-foreground hover:text-foreground"
              }`}>
                Companies
              </Link>
              <Link href="/candidates" className={`transition-colors ${
                location === "/candidates" 
                  ? "text-primary font-medium" 
                  : "text-muted-foreground hover:text-foreground"
              }`}>
                Candidates
              </Link>
              <Link href="/jobs" className={`transition-colors ${
                location === "/jobs" 
                  ? "text-primary font-medium" 
                  : "text-muted-foreground hover:text-foreground"
              }`}>
                Jobs
              </Link>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="button-notifications">
              <Bell size={18} />
            </button>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground text-sm font-medium">JD</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
