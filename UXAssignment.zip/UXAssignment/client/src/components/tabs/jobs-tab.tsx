import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Eye, Edit, Share, MapPin, Clock, DollarSign, Calendar } from "lucide-react";
import { type Job } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import JobFormDialog from "@/components/job-form-dialog";

interface JobsTabProps {
  companyId: string;
}

export default function JobsTab({ companyId }: JobsTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: jobs, isLoading } = useQuery<Job[]>({
    queryKey: ["/api/companies", companyId, "jobs"],
  });

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>;
      case "draft":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Draft</Badge>;
      case "closed":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Closed</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">{status}</Badge>;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? "s" : ""} ago`;
  };

  const filteredJobs = jobs?.filter((job) => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
                         job.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-10 bg-muted rounded-lg mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
            <Input
              type="text"
              placeholder="Search jobs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-80"
              data-testid="input-search-jobs"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48" data-testid="select-status-filter">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <JobFormDialog companyId={companyId} />
      </div>

      <div className="grid gap-4">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => (
            <div key={job.id} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow" data-testid={`card-job-${job.id}`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-foreground">{job.title}</h3>
                    {getStatusBadge(job.status)}
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-3">
                    {job.location && (
                      <div className="flex items-center">
                        <MapPin className="w-4 mr-1" />
                        <span>{job.location}</span>
                      </div>
                    )}
                    {job.type && (
                      <div className="flex items-center">
                        <Clock className="w-4 mr-1" />
                        <span>{job.type}</span>
                      </div>
                    )}
                    {job.salaryRange && (
                      <div className="flex items-center">
                        <DollarSign className="w-4 mr-1" />
                        <span>{job.salaryRange}</span>
                      </div>
                    )}
                    <div className="flex items-center">
                      <Calendar className="w-4 mr-1" />
                      <span>
                        {job.status === "Draft" 
                          ? `Draft saved ${formatTimeAgo(job.createdAt!)}`
                          : `Posted ${formatTimeAgo(job.createdAt!)}`
                        }
                      </span>
                    </div>
                  </div>
                  <p className="text-foreground text-sm">{job.description}</p>
                </div>
                <div className="flex flex-col items-start lg:items-end space-y-2">
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="text-center">
                      <div className="font-semibold text-foreground">
                        {job.status === "Draft" ? "-" : job.applicationCount || 0}
                      </div>
                      <div className="text-muted-foreground">Applications</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-foreground">
                        {job.status === "Draft" ? "-" : job.interviewCount || 0}
                      </div>
                      <div className="text-muted-foreground">Interviews</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" data-testid={`button-view-${job.id}`}>
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" data-testid={`button-edit-${job.id}`}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    {job.status === "Draft" ? (
                      <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid={`button-publish-${job.id}`}>
                        Publish
                      </Button>
                    ) : (
                      <Button variant="ghost" size="sm" data-testid={`button-share-${job.id}`}>
                        <Share className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            {searchTerm || statusFilter !== "all" 
              ? "No jobs match your search criteria" 
              : "No jobs found for this company"
            }
          </div>
        )}
      </div>
    </div>
  );
}
