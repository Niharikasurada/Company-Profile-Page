import { MapPin, Users, Building, Plus, Phone, Edit } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { type Company, type Contact, type Job, type Candidate } from "@shared/schema";
import { Button } from "@/components/ui/button";
import JobFormDialog from "@/components/job-form-dialog";

interface CompanyHeaderProps {
  company: Company;
}

export default function CompanyHeader({ company }: CompanyHeaderProps) {
  const { data: contacts } = useQuery<Contact[]>({
    queryKey: ["/api/companies", company.id, "contacts"],
  });

  const { data: jobs } = useQuery<Job[]>({
    queryKey: ["/api/companies", company.id, "jobs"],
  });

  const { data: candidates } = useQuery<Candidate[]>({
    queryKey: ["/api/companies", company.id, "candidates"],
  });

  const activeJobs = jobs?.filter(job => job.status === "Active").length || 0;
  const totalContacts = contacts?.length || 0;
  const totalCandidates = candidates?.length || 0;

  const getLastActivity = () => {
    // Simple calculation for demo - in real app would fetch from activities
    return "2d ago";
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm p-6 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div className="flex items-start space-x-4">
          <img
            src={company.logoUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"}
            alt={`${company.name} logo`}
            className="w-16 h-16 rounded-lg object-cover border border-border"
          />
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground">{company.name}</h1>
            <div className="mt-2 space-y-1">
              {company.industry && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Building className="w-4 mr-2" />
                  <span>{company.industry}</span>
                </div>
              )}
              {company.location && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="w-4 mr-2" />
                  <span>{company.location}</span>
                </div>
              )}
              {company.size && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Users className="w-4 mr-2" />
                  <span>{company.size}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <JobFormDialog companyId={company.id} />
          <Button variant="secondary" data-testid="button-log-call">
            <Phone className="w-4 h-4 mr-2" />
            Log Call
          </Button>
          <Button variant="outline" data-testid="button-edit-company">
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-border">
        <div className="text-center">
          <div className="text-2xl font-bold text-foreground" data-testid="stat-active-jobs">
            {activeJobs}
          </div>
          <div className="text-sm text-muted-foreground">Active Jobs</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-foreground" data-testid="stat-contacts">
            {totalContacts}
          </div>
          <div className="text-sm text-muted-foreground">Contacts</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-foreground" data-testid="stat-candidates">
            {totalCandidates}
          </div>
          <div className="text-sm text-muted-foreground">Candidates</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-foreground" data-testid="stat-last-activity">
            {getLastActivity()}
          </div>
          <div className="text-sm text-muted-foreground">Last Activity</div>
        </div>
      </div>
    </div>
  );
}
