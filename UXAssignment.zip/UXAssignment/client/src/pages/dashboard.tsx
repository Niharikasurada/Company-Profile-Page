import { useQuery } from "@tanstack/react-query";
import { type Company, type Contact, type Job, type Candidate } from "@shared/schema";
import Header from "@/components/header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, Users, Briefcase, UserCheck } from "lucide-react";

export default function Dashboard() {
  const { data: companies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const totalCompanies = companies?.length || 0;
  const activeCompanies = companies?.filter(c => c.status === "Active").length || 0;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-2">Overview of your recruitment activities</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Building className="text-primary" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-foreground">{totalCompanies}</p>
                <p className="text-sm text-muted-foreground">Total Companies</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <UserCheck className="text-green-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-foreground">{activeCompanies}</p>
                <p className="text-sm text-muted-foreground">Active Companies</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Briefcase className="text-blue-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-foreground">-</p>
                <p className="text-sm text-muted-foreground">Active Jobs</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Users className="text-purple-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-foreground">-</p>
                <p className="text-sm text-muted-foreground">Total Candidates</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Recent Companies</h3>
            <div className="space-y-3">
              {companies?.slice(0, 5).map((company) => (
                <div key={company.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <img
                      src={company.logoUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                      alt={`${company.name} logo`}
                      className="w-10 h-10 rounded-lg object-cover"
                    />
                    <div>
                      <p className="font-medium text-foreground">{company.name}</p>
                      <p className="text-sm text-muted-foreground">{company.industry}</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                    {company.status}
                  </Badge>
                </div>
              )) || (
                <p className="text-muted-foreground">No companies available</p>
              )}
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full p-3 text-left bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="font-medium text-foreground">Add New Company</div>
                <div className="text-sm text-muted-foreground">Create a new company profile</div>
              </button>
              <button className="w-full p-3 text-left bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="font-medium text-foreground">Post New Job</div>
                <div className="text-sm text-muted-foreground">Create a new job posting</div>
              </button>
              <button className="w-full p-3 text-left bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="font-medium text-foreground">Add Candidate</div>
                <div className="text-sm text-muted-foreground">Add a new candidate to the system</div>
              </button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}